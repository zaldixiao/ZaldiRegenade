# 🌌 ZaldiRegenade 🌌

**“Berjalan di antara awan, mengejar keabadian — Donghua adalah jalanku.”**

- 🔭 Fokus saat ini: Donghua Theme Project
- 💻 Bahasa favorit: HTML, CSS, JavaScript, Python
- 🌐 Website: zaldiRegenade.github.io
- 📫 Kontak: xiaozall2007@gmail.com

> “Langit dan bumi mungkin hancur, tapi semangat yang tak menyerah akan tetap abadi.”
